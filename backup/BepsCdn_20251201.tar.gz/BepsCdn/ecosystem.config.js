module.exports = {
  apps : [{
    name: 'beps_cdn',
    script: 'server.js',
    max_memory_restart: '120M',
    node_args: '--max-old-space-size=512',
    instances: 'max',
    exec_mode: 'cluster',    
    out_file: "./logs/beps_cdn_out.log",
    error_file: "./logs/beps_cdn_error.log",
    log_date_format: "YYYY-MM-DD HH:mm:ss",
    max_restarts: 5,
    autorestart: true,
    watch: false
  }],
};

