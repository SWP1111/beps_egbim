module.exports = {
    CONTENTS_DIR: '/mnt/beps_contents',    
    APPLICATION_DIR: '/mnt/application',
    SECRET_KEY: 'beps@ccp',
    PASSWORD: 'beps@hmeg'
};
